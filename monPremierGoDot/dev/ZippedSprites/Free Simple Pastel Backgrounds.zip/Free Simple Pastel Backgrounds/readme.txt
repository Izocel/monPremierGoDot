

 Thank you for download my Free Simple Pastel Backgrounds!

 Feel free to send me messages or leave a comment if you have questions or need more info.


 *Info

   Artwork created by Eder Muniz

   PNG, PSD Formats


FAQ:
Q: Can I use on my free/commercial game?
A: Yes you can use.

Q: Do I need to credit you?
A: Yes you need, all my free assets need credits, the paid ones there's no need. To credit me just put my name (Eder Muniz), my itch page or my twitter username (@edermunizz or @edermunizpixels)

Q: Can I use on my twitch cover?
A: Yes you can use in anything.

Q: Can I modify this asset?
A: Yes of course!

Q: Can I redistribute if I change this asset?
A: No, you can't distibutte this asset in any way, even if you modify.

Q: Can I use in more than one game?
A: Yes you can use in many games as you like.


